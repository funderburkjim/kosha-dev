<?php
$dictcode = "acph";
$dictwebversion = "03.004";
?>
