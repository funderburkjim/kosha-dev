<?php
$dictcode = "abch";
$dictwebversion = "03.004";
?>
